// infrastructure/adapters/input/rest/data/request/ClienteRequest.java
package com.banco.alura.modules.cliente.infrastructure.adapters.input.rest.data.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import java.time.LocalDate;

@Data
public class ClienteRequest {
    @NotBlank
    private String nombre;
    @NotBlank
    private String apellido;
    private LocalDate fechaNacimiento;
    @Email
    private String email;
    private String telefono;
}